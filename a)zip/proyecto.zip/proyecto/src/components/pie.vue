<script setup>

</script>

<template>
    <footer id="pie">
        Esta web está marcada con <a href="http://creativecommons.org/publicdomain/zero/1.0?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">CC0 1.0<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1"><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/zero.svg?ref=chooser-v1"></a>
    </footer>
</template>

<style scoped>
    #pie {
        background-color: #00ff73;
        position: absolute;
        bottom: 0;
        width: 100%;
        text-align: center;
        padding-top: 3px;
    }
</style>