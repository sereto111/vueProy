<script setup>
import cabecera from "./components/cabecera.vue";
import pie from "./components/pie.vue";

</script>

<template>
  <cabecera/>  

  <pie/>
</template>

<style scoped>

</style>
